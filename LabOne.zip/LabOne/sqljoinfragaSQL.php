SELECT book.ISBN, book.title, author.firstname, author.lastname FROM book
JOIN library ON book.ISBN = library.ISBN
JOIN author ON author.id = library.id


book.ISBN = library.ISBN = fatta att det hör ihop. För att en bok ska kunna ha fler författare och tvärtom. 

vad gör en jon? Conectar andra tabellernas till en stor.  Men join gör man “en tabell” av de andra man har.