<!DOCTYPE html>
<?php include ('header.php'); ?>
<?php include('config.php');?>

    <header>
      <a href="#"> <img src="phone.jpg" /></a>
    </header>

    <section class="maincontent2">
      <h2>Contact</h2>
      <p class="contact-text">Talk to us and give us feedback! <br/> </p>
      <form class="contact" action="/action_page.php">
        <input type="text" id="name" name="name" placeholder="Name"><br>
        <input type="text" id="email" name="emial" placeholder="E-mail"><br>
        <textarea id="subject" name="subject" placeholder="Message" style="height:100px"></textarea><br>
        <input type="submit" value="Submit">
      </form>
    </section>

    <?php include ('footer.php'); ?>

    </section>
  </body>
</html>