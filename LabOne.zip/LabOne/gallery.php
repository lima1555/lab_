<!DOCTYPE html>
<html>

		<?php include ('header.php');
			      include('config.php'); ?>


   			 <?php 
                    $dirname = "Admin/files/";
                       $images = glob($dirname."*");
                      foreach($images as $image) {
                     echo '<img src="'.$image.'" /><br />';
                  };

               ?>

 <?php include('footer.php');?>