<footer>
	<p>© | Ansvarig utgivare: Matilda Lindh | Kontakta matilda@koda.se</p>
 </footer>