<!-- Kod är till för att kunna se bilderna  -->

				<?php 
                    $dirname = "Files/";
                       $images = glob($dirname."*");
                      foreach($images as $image) {
                     echo '<img src="'.$image.'" /><br />';
                  };

               ?>