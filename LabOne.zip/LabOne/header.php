<head>
	<?php include('config.php');?>
	<link rel="stylesheet" type="text/css" href="mystyle_labone.css">
	<link href="https://fonts.googleapis.com/css?family=Open+Sans" rel="stylesheet">
	<title>Book Club</title>
</head>

<html>
	<body>
		<section class="all">
			<nav class="topmenu">
			<ul>
				<li><a class="<?php echo ($current_page == 'index.php' || $current_page == '') ? 'active' : NULL ?>" href="index.php">Book Shop</a></li>

				<li><a class="<?php echo ($current_page == '/LabOne/Admin/' || $current_page == '') ? 'active' : NULL ?>" href="/LabOne/Admin">Admin</a></li>

				<li><a class="<?php echo ($current_page == 'LabOne_Brosbooks.php') ? 'active' : NULL ?>" href="LabOne_Brosbooks.php">Brows Books</a></li>

				<li><a class="<?php echo ($current_page == 'LabOne_mybooks.php') ? 'active' : NULL ?>" href="LabOne_mybooks.php">My Books</a></li>

				<li><a class="<?php echo ($current_page == 'LabOne_AboutUs.php') ? 'active' : NULL ?>" href="LabOne_AboutUs.php">About Us</a></li>

				<li><a class="<?php echo ($current_page == 'LabOne_contact.php') ? 'active' : NULL ?>" href="LabOne_contact.php">Contact</a></li>

				<li><a class="<?php echo ($current_page == 'gallery.php' || $current_page == '') ? 'active' : NULL ?>" href="gallery.php">Images</a></li>
			</ul>
				</nav>


				