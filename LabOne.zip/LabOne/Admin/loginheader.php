<?php

session_start();
if (!isset($_SESSION['userid'])) {
    header("login.php");
}

//PUT THIS HEADER ON TOP OF EACH UNIQUE PAGE