<head>
	<?php include('config.php');?>
	<link rel="stylesheet" type="text/css" href="mystyle_labone.css">
	<link href="https://fonts.googleapis.com/css?family=Open+Sans" rel="stylesheet">
	<title>Admin</title>
</head>

<html>
	<body>
		<section class="all">
			<h1>Admin</h1>
			<nav class="topmenu">
			<ul>

				<li><a class="<?php echo ($current_page == '../index.php') ? 'active' : NULL ?>" href="../index.php">Home</a></li>
		
				<li><a class="<?php echo ($current_page == 'index.php') ? 'active' : NULL ?>" href="index.php">All books</a></li>

				<li><a class="<?php echo ($current_page == 'addbook.php') ? 'active' : NULL ?>" href="addbook.php">Add book</a></li>

				<li><a class="<?php echo ($current_page == 'fileUpload.php') ? 'active' : NULL ?>" href="fileUpload.php">Upload image</a></li>

				
			</ul>
				</nav>


				