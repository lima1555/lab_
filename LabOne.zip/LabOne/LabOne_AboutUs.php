<!DOCTYPE html>
<?php include ('header.php'); ?>
<?php include('config.php');?>

		<header>
			<a href="#"> <img src="kaffe.jpg" /></a>
		</header>

			<section class="maincontent2">
				<h2>About us:</h2>
					<p class="welcome-text">Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempori ncididunt ut et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut
				ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore
				eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.</p>
			</section>

			<?php include ('footer.php'); ?>

		</section>
	</body>
</html>